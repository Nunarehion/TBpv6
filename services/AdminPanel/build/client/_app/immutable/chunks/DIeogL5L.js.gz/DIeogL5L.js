let e=!1,a=!1;function l(){e=!0}export{l as e,e as l,a as t};
